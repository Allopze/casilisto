const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B5lWy25W.js","assets/index-DDMGNmkr.js","assets/index-CQtn_g_v.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DDMGNmkr.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-B5lWy25W.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
